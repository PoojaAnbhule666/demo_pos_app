//
//  Use this file to import your target's public headers that you would like to expose to Swift.
//

#ifndef SampleCode-SPoC_Bridging_Header_h
#define SampleCode-SPoC_Bridging_Header_h

#import <IDTech/IDTech.h>
#import <mcSDKiOS/mcSDKiOS.h>



#endif /* SampleCode-SPoC_Bridging_Header_h */
