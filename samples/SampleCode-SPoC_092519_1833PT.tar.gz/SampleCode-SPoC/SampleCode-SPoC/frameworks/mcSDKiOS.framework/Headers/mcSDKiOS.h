//
//  mcSDKiOS.h
//  mcSDKiOS
//
//  Created by Mike Adams on 8/2/19.
//  Copyright © 2019 MagicCube. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for mcSDKiOS.
FOUNDATION_EXPORT double mcSDKiOSVersionNumber;

//! Project version string for mcSDKiOS.
FOUNDATION_EXPORT const unsigned char mcSDKiOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <mcSDKiOS/PublicHeader.h>
#import <mcSDKiOS/CubeFramework.h>


