//
//  HexUtilities.swift
//  MagicCubeRef
//
//  Created by Mike Adams on 8/23/19.
//  Copyright © 2019 MagicCube. All rights reserved.
//

import Foundation
public class HexUtilities {
    
    let terminatorByte : UInt32 = 999
    
    
    public func getTerminatorByte() -> UInt32
    {
        return terminatorByte;
    }
    
    
    public func bytesToHex(request: [UInt32]) -> String {
        
        var hexString : String = ""
        var iii = 0;
        while request[iii] != terminatorByte
        {
            hexString += byteToHex(number: request[iii])
            iii+=1
        }
        return hexString
    }
    public func byteToHex(number: UInt32) -> String {
        
        let indexOne = number / 16
        let indexTwo = number - (indexOne * 16)
        return getHexDigit(number: indexOne) + getHexDigit(number: indexTwo)
    }
    public func getHexDigit(number: UInt32) -> String {
        
        if number == 0 {
            return "0"
        } else if number == 1 {
            return "1"
        } else if number == 2 {
            return "2"
        } else if number == 3 {
            return "3"
        } else if number == 4 {
            return "4"
        } else if number == 5 {
            return "5"
        } else if number == 6 {
            return "6"
        } else if number == 7 {
            return "7"
        } else if number == 8 {
            return "8"
        } else if number == 9 {
            return "9"
        } else if number == 10 {
            return "A"
        } else if number == 11 {
            return "B"
        } else if number == 12 {
            return "C"
        } else if number == 13 {
            return "D"
        } else if number == 14 {
            return "E"
        } else if number == 15 {
            return "F"
        }
        
        return "0"
    }
    func getByteArray(_ data: String) -> UnsafeMutablePointer<UInt32>!
    {
        if data.count < 2  || Int(data.count) % 2 != 0
        {
            let uint32Pointer = UnsafeMutablePointer<UInt32>.allocate(capacity: 2)
            uint32Pointer[0] = 0;
            uint32Pointer[1] = 999;
            return uint32Pointer;
        }
        var jjj = 0;
        let uint32Pointer = UnsafeMutablePointer<UInt32>.allocate(capacity: data.count / 2 + 1)
        let characters = Array(data)//data.charactersArray
        while (jjj + 1) < data.count
        {
            let numberOne = characters[jjj]
            let numberTwo = characters[jjj+1]
            let number : Int32 =  ((getNumberFromCharacter(character: numberOne) * 16) + (getNumberFromCharacter(character: numberTwo)))
            uint32Pointer[jjj / 2] = UInt32(number)
            jjj+=2
        }
        uint32Pointer[jjj / 2] = terminatorByte
        return uint32Pointer
        
        
    }
    func getNumberFromCharacter(character : Character) -> Int32
    {
        if character == "0"
        {
            return 0
        } else if character == "1"
        {
            return 1
        } else if character == "2"
        {
            return 2
        } else if character == "3"
        {
            return 3
        } else if character == "4"
        {
            return 4
        } else if character == "5"
        {
            return 5
        } else if character == "6"
        {
            return 6
        } else if character == "7"
        {
            return 7
        } else if character == "8"
        {
            return 8
        } else if character == "9"
        {
            return 9
        } else if character == "a"
        {
            return 10
        } else if character == "b"
        {
            return 11
        } else if character == "c"
        {
            return 12
        } else if character == "d"
        {
            return 13
        } else if character == "e"
        {
            return 14
        } else if character == "f"
        {
            return 15
        }
        return 0
    }
    
}
