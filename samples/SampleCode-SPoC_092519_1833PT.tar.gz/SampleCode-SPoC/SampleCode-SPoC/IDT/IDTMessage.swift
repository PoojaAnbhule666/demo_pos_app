//
//  IDTMessage.swift
//  MagicCubeRef
//
//  Created by AT on 6/7/19.
//  Copyright © 2019 MagicCube. All rights reserved.
//

import Foundation

enum IDTMessage: String, Notifiable {
    typealias ParameterType = String

    case LCD
}
