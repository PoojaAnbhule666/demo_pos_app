//
//  IdtNotification.swift
//  MagicCubeRef
//
//  Created by AT on 5/1/19.
//  Copyright © 2019 MagicCube. All rights reserved.
//

import Foundation

enum IDTNotification: String, NoParamNotifiable {
    case emvApproved
    case emvDenied
}
