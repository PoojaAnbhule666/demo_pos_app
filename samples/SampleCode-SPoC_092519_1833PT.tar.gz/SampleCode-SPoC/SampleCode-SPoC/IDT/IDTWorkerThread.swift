//
//  IDTWorkerThread.swift
//  MagicCubeRef
//
//  Created by A🐶T on 04/03/19.
//  Copyright © 2019 MagicCube. All rights reserved.
//

import UIKit

//import RxCocoa
//import RxSwift
//import McSdk
protocol TransactionUIProtocol : NSObject {
    func pinCanceled()
    func emvApproved()
    func emvDeclined()
    func devicePaired()
    func emvStarted()
    func deviceDisconnected()
    func devicePairStart()
    func postMessage(text : String)
    func getMessage() -> String
    func fallback()
    
}

internal class IDTWorkerThread {
    
    
    init() {
        self.idtNeo2Mc.open()
    }

    deinit {
        //print("IDTWorkerThread deinit")
        self.idtNeo2Mc.close()
    }

    func devicePairStart(deviceName: String) {
        UserDefaults.standard.set(deviceName, forKey: Const.deviceNameKey)
        UserDefaults.standard.synchronize()

        self.idtNeo2Mc.pairStart(deviceName: deviceName)
    }

    func deviceStartTransaction(amount: Double) {
        self.idtNeo2Mc.startTransaction(amount: amount)
        
    }
    
    func deviceDisconnect() {
        self.idtNeo2Mc.disconnect()
    }

    func isConnected() -> Bool {
        return self.idtNeo2Mc.isConnected()
    }

    func deviceName() -> String {
        if let deviceName = (UserDefaults.standard.value(forKey: Const.deviceNameKey) as? String) {
            return deviceName
        } else {
            return Const.defaultDeviceName
        }
    }
    
    func setTransactionProtocolDelegate(vc : ViewController)  {
        self.idtNeo2Mc.delegate = vc
    }
    
    private class IDTNEO2MC: NSObject, IDT_NEO2_Delegate, mcSDKProtocol {
        
        weak var delegate: TransactionUIProtocol?
        let serialQueue = DispatchQueue(label: "co.magiccube.idt")
        var transactionState : TransactionState  = TransactionState.DOWN
        let hexUtilities = HexUtilities()
        var dataLog  = ""
        
        let MCDECODERIDENTIFIER  = "4D43"
        enum TransactionState {
            case DOWN,
            STARTED,
            KILLED,
            PEDUP
        }

        public func open() {
            self.run(onMain: false, strongify: self) { this in
                // use the shared instance for now
                // IDT_NEO2() freezes the UI
                this.idtNeo2 = IDT_NEO2.sharedController()
//                this.idtNeo2 = IDT_NEO2()
                this.idtNeo2.delegate = this
            }
        }

        public func close() {
            self.disconnect()
            self.idtNeo2.delegate = nil
        }

        public func isConnected() -> Bool {
            return self.idtNeo2.isConnected()
        }

        deinit {
            //print("IDTNEO2MC deinit")
        }

        public func pairStart(deviceName: String) {
            if !isConnected() {
                self.delegate!.devicePairStart()
                self.run(onMain: false, strongify: self) { this in
                    this.idtNeo2.device_setBLEFriendlyName(deviceName)
                    this.idtNeo2.device_enableBLEDeviceSearch(nil)
                }
            }
        }

        public func disconnect() {
            self.delegate!.deviceDisconnected()
            self.run(onMain: false, strongify: self) { this in
                this.idtNeo2.device_disconnectBLE()
            }
        }

        public func startTransaction(amount: Double) {
            self.delegate!.emvStarted()
            self.run(onMain: false, strongify: self) { this in
            let tags = IDTUtility.hex(toData: "DFEF370106DFEF1F020100DFEF3C03010060DFEE22033C3C3C")
           // "DFEF370106DFEF1F020100DFEF3C03010060DFEE22033C3C3C"
            let result = self.idtNeo2.device_startTransaction(amount,
                                                                  type: 0,
                                                                  timeout: IdtConst.transactionTimeout,
                                                                  tags: tags)
            

            if RETURN_CODE_DO_SUCCESS == result {
                   // print("Start transaction command accepted.")
                self.transactionState = TransactionState.STARTED
                   
            } else {
                   // print("Start transaction command failed \(result).")
            }
          }
        }
        func data(inOutMonitor data: Data!, incoming isIncoming: Bool) {
            if isIncoming {
                dataLog += " IN "
            } else {
                dataLog += " Out "
            }
            dataLog += data.description
            dataLog += " hex is: "
            dataLog += data.hexEncodedString()
            dataLog += "\n"
            
           // print("log data is: \(dataLog)")
        }
        
        public func getDeviceName() -> String {
            return self.idtNeo2.device_getBLEFriendlyName()
        }

        // IDT_NEO2_Delegate
        func deviceConnected() {
            //print("deviceConnected running on main: \(Thread.isMainThread)")
            //print(IDT_Device.sdk_version())
            let cube : CubeFramework = mcSDKiOS.CubeFramework.getInstance()
            cube.delegate = self;
            CubeFramework.pair();
            delegate?.devicePaired()
        }
        func swipeMSRData(_ cardData: IDTMSRData!) {
             if cardData.event == EVENT_MSR_DATA_ERROR {
                if(transactionState == TransactionState.STARTED) {
                    delegate?.pinCanceled()
                    transactionState = TransactionState.KILLED
                }
                
            }
        }
        
        

        func lcdDisplay(_ mode: Int32, lines: [Any]!) {
            //print("mode is \(mode)")
            guard let lines = lines else {
                return
            }

            var result = ""
            for line in lines {
                if let line = line as? String {
                    if line.count > 0 {
                        result += line
                        result += "\n"
                    }
                }
            }

            if result.count > 0 {
                //IDTMessage.LCD.post(parameter: result)
                delegate?.postMessage(text: result)
            }
        }
    
        
        func emvTransactionData(_ emvData: IDTEMVData!, errorCode error: Int32) {
            if let emvData = emvData {
                if emvData.resultCodeV2.rawValue == RETURN_CODE_NEO_REQUEST_ONLINE_AUTHORIZATION.rawValue {
                    _ = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(requestOnlineAuthorization), userInfo: nil, repeats: false)
                    delegate?.postMessage(text: "REQUEST ONLINE AUTHORIZATION")
                }
                else if emvData.resultCodeV2 == EMV_RESULT_CODE_V2_GO_ONLINE {
                    self.completeEMVTransaction()
                }
                else if emvData.resultCodeV2 == EMV_RESULT_CODE_V2_APPROVED {
                    delegate?.emvApproved()
                }
                else if emvData.resultCodeV2 == EMV_RESULT_CODE_V2_DECLINED {
                    delegate!.emvDeclined()
                }  else if emvData.resultCodeV2 == EMV_RESULT_CODE_V2_FALLBACK_SITUATION {
                    //print("fallback")
                    cardInsertedIncorrect()
                }
                else {
                    //print("uncaught emvData error with emvData: \(error) and result code \(emvData.resultCodeV2)")
                    
                    
                }
            } else {
                //print("emvData error: \(error)")
            }
        }
        
        @objc func requestOnlineAuthorization() {
            delegate?.pinCanceled()
        }
        
        func completeEMVTransaction() {
            self.run(onMain: true, strongify: self) { this in
                // tag 8A success
                let tags = IDTUtility.hex(toData: "8A023030")
                let result = this.idtNeo2.emv_completeOnlineEMVTransaction(true, hostResponseTags: tags)
                self.transactionState = TransactionState.DOWN

                //print(result)
            }
        }
        
        func cardInsertedIncorrect() {
            self.delegate!.fallback()
            self.run(onMain: true, strongify: self) { this in
                let rt: RETURN_CODE = self.idtNeo2.emv_callbackResponsePIN(EMV_PIN_MODE_Types(rawValue: 0),
                                                                           ksn: nil,
                                                                           pin: nil)
                self.transactionState = TransactionState.KILLED
            }
        }
        func pinEntryCanceled() {
            self.delegate!.pinCanceled()
            self.run(onMain: true, strongify: self) { this in
                let rt: RETURN_CODE = self.idtNeo2.emv_callbackResponsePIN(EMV_PIN_MODE_Types(rawValue: 0),
                                                                      ksn: nil,
                                                                      pin: nil)
                self.transactionState = TransactionState.KILLED
            }
        }
        
        func txrx(_ data: UnsafeMutablePointer<UInt32>!) -> UnsafeMutablePointer<UInt32>! {
            var request : [UInt8] = [UInt8]();
            var mmm = 0;
            while data[mmm] != hexUtilities.getTerminatorByte() {
                request.append(UInt8(data[mmm]))
                mmm+=1
            }
            
            if (request.count >= 8 && request[0] == 0x06 && request[1] == 02)
            {
                if(transactionState != TransactionState.PEDUP) {
                    
                    let uint32Pointer = UnsafeMutablePointer<UInt32>.allocate(capacity: 2)
                    uint32Pointer[0] = 0;
                    uint32Pointer[1] = hexUtilities.getTerminatorByte();
                    return uint32Pointer;
                }
                
                    //let pin: String? = String(bytes: request, encoding: .utf8)
                let pin: String? = String(bytes: request, encoding: .utf8)
                if let pin = pin {
                    let rt: RETURN_CODE = idtNeo2.emv_callbackResponsePIN(pinMode,
                                                             ksn: nil,
                                                             pin: pin.data(using: .utf8))
                        if RETURN_CODE_DO_SUCCESS == rt {
                            //print("pin success")
                        } else {
                            //print("pin failed and response code is \(rt)")
                        }
                    
                    } else {
                        idtNeo2.emv_callbackResponsePIN(EMV_PIN_MODE_CANCEL,
                                                             ksn: nil,
                                                             pin: nil)
                    }
                transactionState = TransactionState.STARTED;
                let uint32Pointer = UnsafeMutablePointer<UInt32>.allocate(capacity: 2)
                uint32Pointer[0] = 0
                uint32Pointer[1] = hexUtilities.getTerminatorByte()
                return uint32Pointer;
            }
            var request32 = [UInt32]()
            for number in request {
                request32.append(UInt32(number))
            }
            request32.append(hexUtilities.getTerminatorByte())
            let dataInput : String = hexUtilities.bytesToHex(request: request32)
            let commandInput = "4D"
            let subCommandInput = "43"
            
            var commandValue: UInt32 = 0
            var scanner = Scanner.localizedScanner(with: commandInput)
            (scanner as AnyObject).scanHexInt32(&commandValue)
            
            var subCommandValue: UInt32 = 0
            scanner = Scanner.localizedScanner(with: subCommandInput)
            (scanner as AnyObject).scanHexInt32(&subCommandValue)
            
            let data = IDTUtility.hex(toData: dataInput)
            var response: NSData?
            if transactionState == IDTNEO2MC.TransactionState.PEDUP {
                IDT_Device.bypassEventCheck(true)
            }
            let rt: RETURN_CODE = IDT_NEO2.sharedController().device_sendIDGCommand(UInt8(commandValue), subCommand: UInt8(subCommandValue), data: data, response: &response)
            if RETURN_CODE_DO_SUCCESS == rt {
            }
            if response != nil {
                let data = Data(referencing: (response ?? nil)!)
                let hexStringResponse = data.hexEncodedString()
                return hexUtilities.getByteArray(hexStringResponse)
            }
            let uint32Pointer = UnsafeMutablePointer<UInt32>.allocate(capacity: 2)
            uint32Pointer[0] = 0;
            uint32Pointer[1] = hexUtilities.getTerminatorByte();
            return uint32Pointer;
        }
        
        
        func pinRequest(_ mode: EMV_PIN_MODE_Types,
                        key: Data!,
                        pan PAN: Data!,
                        startTO: Int32,
                        intervalTO: Int32,
                        language: String!) {
            //print("pinRequest: enter pin")
            transactionState = IDTNEO2MC.TransactionState.PEDUP
            self.pinMode = mode
            CubeFramework.pinCapture()
            if (delegate?.getMessage().contains("TRY AGAIN"))! {
                delegate?.postMessage(text: "")
            }
            
        }
        
        private func run<Object: AnyObject>(onMain: Bool,
                                            strongify object: Object,
                                            block: @escaping (Object) -> Void) {
            let queue = onMain ?  DispatchQueue.main : self.serialQueue
            queue.async { [weak object] in
                guard let this = object else { return }
                block(this)
                //print(Thread.current)
            }
        }

        private var idtNeo2: IDT_NEO2!
        private var pinMode = EMV_PIN_MODE_CANCEL
    }

   
    private var idtNeo2Mc = IDTNEO2MC()

    fileprivate struct Const {
        static let defaultDeviceName = "IDTECH"
        static let deviceNameKey = "idt_device_name"
    }
}
