//
//  IdtConst.swift
//  MagicCubeRef
//
//  Created by AT on 5/13/19.
//  Copyright © 2019 MagicCube. All rights reserved.
//

import Foundation

public class IdtConst {
    // Time to dismiss the hud if an emv transaction does not complete or timeout.
    // In Seconds.
    static let transactionHudTimeout: TimeInterval = 70.0
    // IDT SDK transaction timeout value in seconds.
    static let transactionTimeout: Int32 = 60
    // Time to dismiss the hud if pairing does not complete or timeout.
    // In Seconds.
    static let pairHudTimeout: TimeInterval = 70.0
}
