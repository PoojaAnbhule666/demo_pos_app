//
//  DataExtension.swift
//  MagicCubeRef
//
//  Created by Mike Adams on 8/14/19.
//  Copyright © 2019 MagicCube. All rights reserved.
//

import Foundation

extension Data {
    func hexEncodedString() -> String {
        return map { String(format: "%02hhx", $0) }.joined()
    }
}
