//
//  SpinnerViewController.swift
//  SampleCode-SPoC
//
//  Created by Mike Adams on 9/3/19.
//  Copyright © 2019 MagicCube. All rights reserved.
//

import Foundation
class SpinnerViewController: UIViewController {
    var spinner = UIActivityIndicatorView(style: .whiteLarge)
    let LCDLabel : UILabel = UILabel(frame: CGRect(x: 25, y: 300, width: 300, height: 50))
    
    override func loadView() {
        view = UIView()
        view.backgroundColor = UIColor(white: 0, alpha: 0.8)
        
        spinner.translatesAutoresizingMaskIntoConstraints = false
        spinner.startAnimating()
        view.addSubview(spinner)
        view.addSubview(LCDLabel)
        LCDLabel.textAlignment = NSTextAlignment.center
        LCDLabel.text = ""
        
        
        spinner.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        spinner.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
    }
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        LCDLabel.frame.origin.x = self.view.bounds.width * 0.1
        LCDLabel.frame.size.width = self.view.bounds.width * 0.8
    }
}
