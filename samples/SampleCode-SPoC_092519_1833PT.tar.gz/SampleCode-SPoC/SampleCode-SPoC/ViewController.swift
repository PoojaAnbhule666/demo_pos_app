//
//  ViewController.swift
//  SampleCode-SPoC
//
//  Created by Mike Adams on 8/23/19.
//  Copyright © 2019 MagicCube. All rights reserved.
//

import UIKit
import mcSDKiOS
class ViewController: UIViewController , TransactionUIProtocol, PaymentProtocol {

    internal var idtWorker: IDTWorkerThread!
    let buyButton:UIButton = UIButton(frame: CGRect(x: 200, y: 400, width: 246, height: 240))
    let priceLabel:UILabel = UILabel(frame: CGRect(x: 200, y: 430, width: 150, height: 24))
    let clearButton:UIButton = UIButton(frame: CGRect(x: 200, y: 100, width: 246, height: 240))
    let clearLabel:UILabel = UILabel(frame: CGRect(x: 200, y: 130, width: 150, height: 24))
    var rock = ""
    
    let vc = ItemViewController()
    var initialWindow = true
    let spinner = SpinnerViewController()
    
    override func loadView() {
        super.loadView()
        rock = CubeFramework.initiate()
        idtWorker = IDTWorkerThread()
        idtWorker.setTransactionProtocolDelegate(vc: self)
        setupLayout()
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        buyButton.frame.origin.x = self.view.bounds.width * 0.25
        buyButton.frame.origin.y = self.view.bounds.height * 0.5
        priceLabel.frame.origin.y = buyButton.frame.origin.y + buyButton.frame.size.height / 2 + priceLabel.frame.size.height + 20
        priceLabel.frame.origin.x = self.view.bounds.width * 0.5 - priceLabel.frame.size.width / 2
        
        clearButton.frame.origin.x = self.view.bounds.width * 0.25
        clearButton.frame.origin.y = self.view.bounds.height * 0.2
        clearLabel.frame.origin.y = clearButton.frame.origin.y + clearButton.frame.size.height / 2 + clearLabel.frame.size.height + 20
        clearLabel.frame.origin.x = self.view.bounds.width * 0.5 - clearLabel.frame.size.width / 2
    }
    func setupLayout()
    {
        
        buyButton.setTitle("Buy", for: UIControl.State.normal )
        buyButton.addTarget(self, action:#selector(self.buyTapped(button:)), for: .touchUpInside)
        let btnImage = UIImage(named: "catalog@3x")
        buyButton.setImage(btnImage , for: UIControl.State.normal)
        self.view.addSubview(buyButton)
        priceLabel.text = "Price $100.00"
        priceLabel.backgroundColor = UIColor.white
        priceLabel.textColor = UIColor.black
        priceLabel.textAlignment = NSTextAlignment.center
        self.view.addSubview(priceLabel)
        
        clearButton.setTitle("Clear", for: UIControl.State.normal )
        clearButton.addTarget(self, action:#selector(self.clearTapped(button:)), for: .touchUpInside)
        let btnImage2 = UIImage(named: "catalog@3x")
        clearButton.setImage(btnImage2 , for: UIControl.State.normal)
        self.view.addSubview(clearButton)
        clearLabel.text = "Clear Data"
        clearLabel.backgroundColor = UIColor.white
        clearLabel.textColor = UIColor.black
        clearLabel.textAlignment = NSTextAlignment.center
        self.view.addSubview(clearLabel)
        
    }
    
    func goToInitialWindow() {
        initialWindow = true
    }
    
    func goToSecondWindow() {
        if(vc.view?.window == nil) {
            initialWindow = false
            self.present(vc, animated: true, completion: nil)
            vc.delegate = self;
        }
        
    }
    
    @objc func buyTapped(button: UIButton) {
        if rock.count < 2 || rock == "fake_rock"
        {
            rock = CubeFramework.initiate()
        }
        if rock.count < 2 || rock == "fake_rock" {
            return
        }
        
        if idtWorker.isConnected() {
            devicePaired()
        } else {
            confirmDeviceName()
        }
    }
    
    @objc func clearTapped(button: UIButton) {
        CubeFramework.clearData()
        rock = ""
        if idtWorker.isConnected() {
           idtWorker.deviceDisconnect()
        }
    }
    
    func processPayment() {
        idtWorker.deviceStartTransaction(amount: 122)
    }
    
    
    fileprivate func confirmDeviceName() {
        let alert = UIAlertController(title: "Please enter device name.", message: nil, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        alert.addTextField(configurationHandler: { [weak self] textField in
            guard let this = self else { return }
            
            textField.placeholder = "device name"
            textField.text = this.idtWorker.deviceName()
        })
        
        alert.addAction(UIAlertAction(title: "Continue", style: .default, handler: { action in
            
            if let name = alert.textFields?.first?.text {
                self.idtWorker.devicePairStart(deviceName: name)
            }
        }))
        
        self.present(alert, animated: true)
    }
    func stopSpinner() {
        if (view?.window != nil) {
            spinner.willMove(toParent: nil)
            spinner.view.removeFromSuperview()
            spinner.removeFromParent()
        } else {
            vc.stopSpinner()
        }
    }
    
    func startSpinner() {
        if (view?.window != nil) {
            addChild(spinner)
            spinner.view.frame = view.frame
            view.addSubview(spinner.view)
            spinner.didMove(toParent: self)
            spinner.LCDLabel.text = ""
            spinner.LCDLabel.isHidden = true
        } else {
            vc.startSpinner()
        }
        
        
    }
    func fallback() {
        buyButton.isEnabled = true
        stopSpinner()
        vc.HUDLabel.text = "Insert Card Correctly"
    }
    func pinCanceled() {
        buyButton.isEnabled = true
        stopSpinner()
        vc.HUDLabel.text = "Transaction Canceled!"
    }
    
    func emvApproved() {
        buyButton.isEnabled = true
        stopSpinner()
        vc.HUDLabel.text = "Transaction Approved!"
    }
    
    func emvDeclined() {
        buyButton.isEnabled = true
        stopSpinner()
        vc.HUDLabel.text = "Transaction Declined!"
    }
    
    func devicePaired() {
        goToSecondWindow()
        buyButton.isEnabled = true
        stopSpinner()
    }
    
    func emvStarted() {
        buyButton.isEnabled = false
        startSpinner()
    }
    
    func deviceDisconnected() {
        stopSpinner()
        if(vc.view?.window != nil) {
            vc.HUDLabel.text = "Device Disconnected!"
        }
    }
    
    func devicePairStart() {
       buyButton.isEnabled = false
       startSpinner()
       postMessage(text: "Pairing")
    }
    func postMessage(text : String) {
        if (vc.isViewLoaded && vc.view?.window != nil) {
            vc.spinner.LCDLabel.text = text
            vc.spinner.LCDLabel.backgroundColor = UIColor.white
            vc.spinner.LCDLabel.textColor = UIColor.black
            vc.spinner.LCDLabel.isHidden = false
        } else {
            spinner.LCDLabel.text = text
            spinner.LCDLabel.backgroundColor = UIColor.white
            spinner.LCDLabel.textColor = UIColor.black
            spinner.LCDLabel.isHidden = false
        }
    }
    func getMessage() -> String {
        if (vc.isViewLoaded && vc.view?.window != nil) {
            return vc.spinner.LCDLabel.text!
        }
        return spinner.LCDLabel.text!
    }
}

