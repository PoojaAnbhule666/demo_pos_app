//
//  ItemViewController.swift
//  SampleCode-SPoC
//
//  Created by Mike Adams on 9/5/19.
//  Copyright © 2019 Mike Adams. All rights reserved.
//

import Foundation
let costLabel = UILabel()
let taxesLabel = UILabel()
let feesLabel = UILabel()
let costPriceLabel = UILabel()
let taxeRateLabel = UILabel()
let taxesPriceLabel = UILabel()
let feesPriceLabel = UILabel()
let totalLabel = UILabel()
let itemLabel = UILabel()
let itemDescription = UILabel()
let purchaseButton = UIButton()
let navBar = UINavigationBar(frame: CGRect(x: 0, y: 44, width: 320, height: 44))



protocol PaymentProtocol : NSObject {
    func processPayment()
}


class ItemViewController: UIViewController {
    weak var delegate: PaymentProtocol?
    let spinner = SpinnerViewController()
    let HUDLabel = UILabel()
    
    override func loadView() {
        super.loadView()
        self.view = UIView()
        self.view.backgroundColor = UIColor.white
        
        view.addSubview(navBar)
        
        let navItem = UINavigationItem(title: "Resume")
        
        let backbutton = UIButton(type: .custom)
        backbutton.setTitle("Back", for: .normal)
        backbutton.addTarget(self, action:#selector(self.backTapped(button:)), for: .touchUpInside)
        backbutton.setTitleColor(UIColor.blue, for: .normal)
        let backItem = UIBarButtonItem(customView: backbutton)
        
       // let backItem = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.done, target: nil, action: #selector(backTapped(button:)))
        navItem.leftBarButtonItem = backItem
        
        navBar.setItems([navItem], animated: false)
        
        purchaseButton.addTarget(self, action:#selector(self.purchaseTapped(button:)), for: .touchUpInside)
    }
    
    @objc func purchaseTapped(button: UIButton) {
        delegate?.processPayment()
    }
    
    @objc func backTapped(button: UIButton) {
        HUDLabel.text = ""
        self.dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        setUpLayout()
        navBar.frame.size.width = self.view.bounds.size.width
    }
    func setUpLayout()
    {
        let fontSize : CGFloat = 18.0
        let extra = 1.25
        let spacer = 1.1
        let y = self.view.frame.height * 3 / 5
        let width = self.view.frame.width
        var rect = CGRect(x : Int(0), y : Int(y), width : Int(width), height : Int(Double(fontSize) * extra))
        totalLabel.frame = rect
        totalLabel.textColor = UIColor.white
        totalLabel.backgroundColor = UIColor.black
        totalLabel.textAlignment = NSTextAlignment.right
        totalLabel.text = "$122.00"
        totalLabel.font = UIFont.systemFont(ofSize: fontSize)
        if totalLabel.superview == nil {
            self.view.addSubview(totalLabel)
        }
        
        
        rect.size.width = rect.size.width / 3
        rect.origin.y -= rect.size.height * CGFloat(spacer)
        feesLabel.frame = rect
        feesLabel.textColor = UIColor.gray
        feesLabel.backgroundColor = UIColor.white
        feesLabel.textAlignment = NSTextAlignment.left
        feesLabel.text = "Service Fee"
        feesLabel.font = UIFont.systemFont(ofSize: fontSize)
        if feesLabel.superview == nil {
            self.view.addSubview(feesLabel)
        }
        rect.size.width = self.view.bounds.size.width * 0.25
        rect.origin.x = self.view.bounds.size.width * 0.75
        feesPriceLabel.frame = rect
        feesPriceLabel.textColor = UIColor.gray
        feesPriceLabel.backgroundColor = UIColor.white
        feesPriceLabel.textAlignment = NSTextAlignment.right
        feesPriceLabel.text = "$2.00"
        feesPriceLabel.font = UIFont.systemFont(ofSize: fontSize)
        if feesPriceLabel.superview == nil {
            self.view.addSubview(feesPriceLabel)
        }
        
        rect.origin.x = 0
        rect.origin.y -= rect.size.height * CGFloat(spacer)
        taxesLabel.frame = rect
        taxesLabel.textColor = UIColor.gray
        taxesLabel.backgroundColor = UIColor.white
        taxesLabel.textAlignment = NSTextAlignment.left
        taxesLabel.text = "Taxes"
        taxesLabel.font = UIFont.systemFont(ofSize: fontSize)
        if taxesLabel.superview == nil {
            self.view.addSubview(taxesLabel)
        }
        
        rect.origin.x = self.view.bounds.size.width * 0.50
        taxeRateLabel.frame = rect
        taxeRateLabel.textColor = UIColor.gray
        taxeRateLabel.backgroundColor = UIColor.white
        taxeRateLabel.textAlignment = NSTextAlignment.right
        taxeRateLabel.text = "20%"
        taxeRateLabel.font = UIFont.systemFont(ofSize: fontSize)
        if taxeRateLabel.superview == nil {
            self.view.addSubview(taxeRateLabel)
        }
        
        rect.origin.x = self.view.bounds.size.width * 0.75
        taxesPriceLabel.frame = rect
        taxesPriceLabel.textColor = UIColor.gray
        taxesPriceLabel.backgroundColor = UIColor.white
        taxesPriceLabel.textAlignment = NSTextAlignment.right
        taxesPriceLabel.text = "$20.00"
        taxesPriceLabel.font = UIFont.systemFont(ofSize: fontSize)
        if taxesPriceLabel.superview == nil {
            self.view.addSubview(taxesPriceLabel)
        }
        
        rect.origin.y -= rect.size.height * CGFloat(spacer)
        rect.origin.x = 0
        costLabel.frame = rect
        costLabel.textColor = UIColor.gray
        costLabel.backgroundColor = UIColor.white
        costLabel.textAlignment = NSTextAlignment.left
        costLabel.text = "Cost"
        costLabel.font = UIFont.systemFont(ofSize: fontSize)
        if costLabel.superview == nil {
            self.view.addSubview(costLabel)
        }
        
        rect.origin.x = self.view.bounds.size.width * 0.75
        costPriceLabel.frame = rect
        costPriceLabel.textColor = UIColor.gray
        costPriceLabel.backgroundColor = UIColor.white
        costPriceLabel.textAlignment = NSTextAlignment.right
        costPriceLabel.text = "$100.00"
        costPriceLabel.font = UIFont.systemFont(ofSize: fontSize)
        if costPriceLabel.superview == nil {
            self.view.addSubview(costPriceLabel)
        }
        
        rect.origin.x = 0
        rect.size.width = self.view.bounds.size.width
        rect.origin.y -= (2 * rect.size.height * CGFloat(spacer))
        itemDescription.frame = rect
        itemDescription.textColor = UIColor.gray
        itemDescription.backgroundColor = UIColor.white
        itemDescription.textAlignment = NSTextAlignment.left
        itemDescription.text = "An extremely brief item description"
        itemDescription.font = UIFont.systemFont(ofSize: fontSize * 0.8)
        if itemDescription.superview == nil {
            self.view.addSubview(itemDescription)
        }
        
        rect.origin.y -= (1.5 * rect.size.height * CGFloat(spacer))
        itemLabel.frame = rect
        itemLabel.textColor = UIColor.black
        itemLabel.backgroundColor = UIColor.white
        itemLabel.textAlignment = NSTextAlignment.left
        itemLabel.text = "Item"
        itemLabel.font = UIFont.boldSystemFont(ofSize: fontSize * 1.4)
        if itemLabel.superview == nil {
            self.view.addSubview(itemLabel)
        }
        
        rect.origin.y -= (1.5 * rect.size.height * CGFloat(spacer))
        rect.origin.x = self.view.bounds.size.width * 0.25
        rect.size.width = self.view.bounds.size.width * 0.5
        HUDLabel.frame = rect
        HUDLabel.textColor = UIColor.black
        HUDLabel.backgroundColor = UIColor.white
        HUDLabel.textAlignment = NSTextAlignment.center
        HUDLabel.font = .systemFont(ofSize: fontSize * 0.9)
        if HUDLabel.superview == nil {
            self.view.addSubview(HUDLabel)
        }
        
        rect.origin.y = self.view.bounds.height  * 0.8
        rect.origin.x = self.view.bounds.width * 0.17
        rect.size.width = self.view.bounds.width * 0.66
        rect.size.height = fontSize * CGFloat(extra * 1.4)
        purchaseButton.frame = rect
        purchaseButton.titleLabel?.font = UIFont.systemFont(ofSize: fontSize )
        purchaseButton.setTitle("PROCESS PAYMENT",for: .normal)
        purchaseButton.setTitleColor(UIColor.white, for: .normal)
       purchaseButton.backgroundColor = UIColor.black
        if purchaseButton.superview == nil {
            self.view.addSubview(purchaseButton)
        }
    }
    func stopSpinner() {
        spinner.willMove(toParent: nil)
        spinner.view.removeFromSuperview()
        spinner.removeFromParent()
    }
    
    func startSpinner() {
        addChild(spinner)
        spinner.view.frame = view.frame
        view.addSubview(spinner.view)
        spinner.didMove(toParent: self)
        spinner.LCDLabel.text = ""
        spinner.LCDLabel.isHidden = true
    }
    
    
    
}
